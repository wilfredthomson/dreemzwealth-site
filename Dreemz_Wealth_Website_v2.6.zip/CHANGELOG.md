# Dreemz Wealth website — change log

## v2.6 — 13 Nov 2026 — wording updates
- Home: removed the line "AMFI-registered Mutual Fund Distributor · Kochi, Kottayam & Dubai" above the headline (identity already shown in the top strip).
- Home intro and home page description: "families in India and NRIs in the UAE" → "individuals and families in India and NRIs living abroad".
- Home "Who we help": "NRIs in the UAE" → "NRIs living abroad".
- "Al Karama, Dubai" → "Dubai" (home contact card, Contact page card, footer, Contact page description, search-engine data).
- Home: "Talk to us in Kerala or in Dubai" → "Reach out to us".
- Disclosures: Wealthy's registered name added — WealthyIN Customer Services Pvt. Ltd.
- Disclosures: "…listed below" → "…listed below in alphabetical order".
- Menu bar: "Disclosures" added as the last page link (before the Book a meeting button) on every page.
- Menu bar "Book a meeting" button: same rounded-rectangle shape on every page (was oval on the Contact page); on hover it stays gold with dark text, brightens slightly and lifts (text used to disappear); on the Contact page it carries a thin gold ring to show the current page.

## v2.5 — 13 Nov 2026 — compliance changes (approved W1–W4, W6–W14, W16–W20; W15 partly; W5 not applied)
- W1–W4: removed "free" offers (home hero button, home closing banner, How We Work step 1, Contact intro).
- W6: "Retirement Investment Planning" → "Retirement Investing" (Home, Services, Services page description).
- W7: "Regular Income Planning" → "Regular Withdrawals (SWP)" with risk wording; home services line now says Systematic Withdrawal Plans.
- W8: "Solutions for each stage of life" → "Mutual fund investing for each stage of life"; How We Work heading → "Requirements first, then the right mutual fund portfolio".
- W9: removed Family Protection Review, Insurance Needs Assessment and the insurance sentence (Services).
- W10: Disclosures page rewritten (Draft A with Wilfred's edits): 18 empanelled AMCs in alphabetical order (SEBI registration numbers to follow), Wealthy empanelment and 40+ AMCs line, "other products exist" line, Wealthy's registrations in their own section, Regular Plan and commission wording, conflicts of interest, scheme documents and risk, calculators (retained), NRI investors, complaints with SCORES / ODR, privacy.
- W11: identity strip on every page ("Wilfred Thomson Varavukalayil · AMFI-registered Mutual Fund Distributor · ARN-359001"); name added to footer identity; duplicate line removed from inner-page brand bar.
- W12: "Wealth creation and family protection" → "Mutual fund investing for every life goal"; "wealth creation" removed from goals list.
- W13: removed assurance wording ("steady income you can rely on", "reliable income stream", "SIP that grows alongside your salary", "build wealth").
- W14: portfolio review offered "when you ask us to".
- W15 (partial): Wealthy certificate image kept (Wilfred's decision); "one of the leading" removed; added "Transactions are processed through the Wealthy platform, using both web and mobile apps" with link to Wealthy's registration details.
- W16: "Book a consultation" → "Book a meeting" (menu button and page buttons).
- W17: "AMFI-registered Mutual Fund Distributor, ARN-359001." added to every page description.
- W18: Manorama Horizon certificate images removed; course titles kept as plain text labelled "Course attended".
- W19: contact form now has a required consent checkbox (Draft B) and a storage/retention note; consent is sent with each enquiry.
- W20: Instagram card text → "Educational posts about mutual fund investing".
- W5 not applied (Calculators kept as-is, by decision). UAE items deferred to the next iteration.

## v2.4 — 12 Nov 2026 — banner and logo refinements
- Home banner: designer's new artwork. Desktop version widened at the decorative edges only (6:1, 240px tall at 1440px wide); separate phone version (3.38:1) served automatically on screens up to 760px.
- Home hero: less top/bottom padding so the Dream | Plan | Invest | Grow line and both buttons show without scrolling on laptops and phones.
- Menu bar slimmer (52px).
- Menu bar logo: transparent horizontal logo in a rounded ivory box with a gold edge.
- Footer logo: transparent stacked logo in a rounded ivory box that fits the logo, centred.
- Removed unused images: old banner files, dreemz-logo.jpg, dreemz-logo-sm.jpg, emblem and earlier logo variants.

## v2.1a — 12 Nov 2026 — menu
- Page links shown in the menu bar on all screens wider than 820px (compact spacing 821–1180px); the "Menu" button is now used only on phones.

## v2.1 — 12 Nov 2026 — visual fixes
- Home banner cropped top and bottom (now 3.87:1, e.g. 1440x372 instead of 1440x500); old banner files removed.
- Menu bar: emblem + text replaced with the transparent horizontal logo (44px high).
- Footer: emblem + text replaced with the transparent stacked logo (fixes the text overlap).
- Browser icons rebuilt from the transparent emblem: favicon.ico (16–256px), 16/32/48 PNG, 180px Apple touch icon (ivory background), 192/512 + site.webmanifest; links versioned (?v=2) to bust caches.

## v2.0 — 12 Nov 2026 — visual refresh (no text/compliance changes)
- Theme changed to brand navy (#0b2a5b), gold and ivory, matching the banner and visiting card.
- Home: new full-width brand banner (1280/1440/1920 WebP + 1440 JPG fallback) at the top.
- Inner pages: ivory brand bar with the new transparent horizontal logo, plus "AMFI-registered Mutual Fund Distributor · ARN-359001".
- Menu moved to a sticky navy bar with a gold rule; gold "Book a consultation" button; the emblem appears in the bar once the logo scrolls away (always shown on phones).
- Navy hero bands with a gold swoosh; gold accents on headings, cards, service rows; navy footer with emblem.
- Mobile: banner trimmed slightly at the sides so the logo and tagline stay legible; navy drop-down menu.
- Files added: assets/img/banner/*, assets/img/brand/*. Files changed: all 8 .html pages, assets/css/style.css, assets/js/main.js.
- Wording is unchanged; compliance items W1–W20 are still pending approval.
